import paymentOptions from "./paymentOptions";

const paymentDetails: any = {
  paymentOptions,
};

export default paymentDetails;

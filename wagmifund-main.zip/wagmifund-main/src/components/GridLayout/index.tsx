import clsx from "clsx";
import type { FC, ReactNode } from "react";

interface Props {
  children: ReactNode;
  className?: string;
  classNameChild?: string;
}

export const GridLayout: FC<Props> = ({
  children,
  className = "",
  classNameChild = "",
}) => {
  return (
    <div
      className={clsx(
        "container mx-auto max-w-screen-xl flex-grow pt-8 pb-2 px-0 sm:px-5",
        className
      )}
    >
      <div className={clsx("grid grid-cols-12 lg:gap-8", classNameChild)}>
        {children}
      </div>
    </div>
  );
};

export const GridItemFour: FC<Props> = ({ children, className = "" }) => {
  return (
    <div
      className={clsx("lg:col-span-4 md:col-span-12 col-span-12", className)}
    >
      {children}
    </div>
  );
};

export const GridItemEight: FC<Props> = ({ children, className = "" }) => {
  return (
    <div
      className={clsx(
        "lg:col-span-8 md:col-span-12 col-span-12 mb-5",
        className
      )}
    >
      {children}
    </div>
  );
};

import ProfileSettings from "@modules/Settings/ProfileSetting";

export default ProfileSettings;
